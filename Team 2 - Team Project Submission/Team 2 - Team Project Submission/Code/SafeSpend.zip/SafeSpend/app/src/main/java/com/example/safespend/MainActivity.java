package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import static com.example.safespend.CoinsActivity.total;

public class MainActivity extends AppCompatActivity {

    DatabaseManager dbm;

    TextView showInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*For the sounds: Microphone, Camera and MoneyList*/
        ImageView insert = (ImageView) this.findViewById(R.id.insertspeech);
        ImageView payNow = (ImageView) this.findViewById(R.id.paySpeech);
        ImageView change = (ImageView) this.findViewById(R.id.changeSpeech);

        /*For the sound: insert*/
        final MediaPlayer PlayInsert = MediaPlayer.create(this, R.raw.insert);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayInsert.start();
            }
        });

        /*For the sound: pay*/
        final MediaPlayer PlayPay = MediaPlayer.create(this, R.raw.pay);
        payNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayPay.start();
            }
        });

        /*For the sound: check*/
        final MediaPlayer PlayCheck = MediaPlayer.create(this, R.raw.check);
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayCheck.start();
            }
        });

        /*Wallet Feature Display For User*/
        dbm = new DatabaseManager(this);

        dbm.open();
        dbm.deleteWallet();
        dbm.createWallet();

        float totalValue = (float) (dbm.getEfifty() * 50 + dbm.getEtwenty() * 20 + dbm.getEten() * 10
                + dbm.getEfive() * 5 + dbm.getEtwo() * 2 + dbm.getEone() * 1
                + dbm.getCfifty() * 0.5 + dbm.getCtwenty() * 0.2 + dbm.getCten() * 0.1
                + dbm.getCfive() * 0.05 + dbm.getCone() * 0.01);
        dbm.close();
        total[0] = totalValue;

        showInfo = findViewById(R.id.total);

        float rt = Float.parseFloat(String.valueOf((getIntent().getFloatExtra("keyname", (float) 0.0))));
        rt += total[0];

        showInfo.setText((String.format("€ " + "%.2f", rt)));



        /*Switch Screen from MAIN ACTIVITY to INSERT MONEY*/
        ImageView insertMoney = (ImageView) findViewById(R.id.insertbutton);
        insertMoney.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, InsertMoney.class);
                startActivity(intent);
            }
        });

        ImageView pay = (ImageView) findViewById(R.id.paybutton);
        pay.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, PayFeature.class);
                startActivity(intent);
            }
        });

        ImageView checkChange = (ImageView) findViewById(R.id.checkChange);
        checkChange.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, CheckChange.class);
                startActivity(intent);
            }
        });

        ImageButton clearButton = findViewById(R.id.ClearButton);
        clearButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ResetActivity.class);
                startActivity(intent);
            }
        });
    }
}