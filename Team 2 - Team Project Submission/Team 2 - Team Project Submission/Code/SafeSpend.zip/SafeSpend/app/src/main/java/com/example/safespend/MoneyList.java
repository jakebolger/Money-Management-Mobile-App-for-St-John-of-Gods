package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.safespend.R;
import com.example.safespend.adaptador.RecyclerAdapter;
import com.example.safespend.model.ItemList;

import java.util.ArrayList;
import java.util.List;

public class MoneyList extends AppCompatActivity implements RecyclerAdapter.RecyclerItemClick, SearchView.OnQueryTextListener {
    private RecyclerView rvList;
    // private SearchView svSearch;
    private RecyclerAdapter adapter;
    private List<ItemList> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money_view);

        initViews();
        initValues();
        //initListener();

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.icon);
    }

    private void initViews(){
        rvList = findViewById(R.id.rvList);
        //svSearch = findViewById(R.id.svSearch);
    }

    private void initValues() {
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rvList.setLayoutManager(manager);

        items = getItems();
        adapter = new RecyclerAdapter(items, this);
        rvList.setAdapter(adapter);
    }
    /*
        private void initListener() {
            svSearch.setOnQueryTextListener(this);
        }
    */
    private List<ItemList> getItems() {
        List<ItemList> itemLists = new ArrayList<>();
        itemLists.add(new ItemList("Fifty Euros", "Click to select.", R.drawable.fifty_euro));
        itemLists.add(new ItemList("Twenty Euros", "Click to select.", R.drawable.twenty_euro));
        itemLists.add(new ItemList("Ten Euros", "Click to select.", R.drawable.ten_euro));
        itemLists.add(new ItemList("Five Euros", "Click to select.", R.drawable.five_euro));
        itemLists.add(new ItemList("Two Euros", "Click to select.", R.drawable.two_euro));
        itemLists.add(new ItemList("One Euro", "Click to select.", R.drawable.one_euro));
        itemLists.add(new ItemList("Fifty Cent", "Click to select.", R.drawable.fifty_cent));
        itemLists.add(new ItemList("Twenty Cent", "Click to select.", R.drawable.twenty_cent));
        itemLists.add(new ItemList("Ten Cent", "Click to select.", R.drawable.ten_cent));
        itemLists.add(new ItemList("Five Cent", "Click to select.", R.drawable.five_cent));
        itemLists.add(new ItemList("Two Cent", "Click to select.", R.drawable.two_cent));
        itemLists.add(new ItemList("One Cent", "Click to select.", R.drawable.one_cent));

        return itemLists;
    }

    @Override
    public void itemClick(ItemList item) {
        Intent intent = new Intent(this, MoneySelection.class);
        intent.putExtra("itemDetail", item);
        startActivity(intent);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        adapter.filter(newText);
        return false;
    }
}