package com.example.safespend;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class PayFeature extends AppCompatActivity {

    private static  final int REQUEST_CODE_SPEECH_INPUT = 1000;
    TextView mTexTv;
    ImageButton mVoiceBtn;
    Button add;

    DatabaseManager dbm;

    float f1;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mic);

        dbm = new DatabaseManager(this);

        mTexTv = findViewById(R.id.textTv);
        mVoiceBtn = findViewById(R.id.voiceBtn);

        mVoiceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speak();
            }
        });

        add = findViewById(R.id.add_result);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rt = (mTexTv.getText().toString());
                f1 = Float.parseFloat(rt);
                Intent intent = new Intent(PayFeature.this, CoinsActivity.class);

                dbm.open();
                if(f1 == 50){
                    if(dbm.getEfifty() > 0){
                        dbm.decreEfifty();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                if(f1 == 20){
                    if(dbm.getEtwenty() > 0){
                        dbm.decreEtwenty();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                if(f1 == 10){
                    if(dbm.getEten() > 0){
                        dbm.decreEten();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                if(f1 == 5){
                    if(dbm.getEfive() > 0){
                        dbm.decreEfive();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                /*Coins!*/
                if(f1 == 2){
                    if(dbm.getEtwo() > 0){
                        dbm.decreEtwo();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                if(f1 == 1){
                    if(dbm.getEone() > 0){
                        dbm.decreEone();
                    }
                    else{
                        Toast.makeText(PayFeature.this,"Insufficient Funds 0_0", Toast.LENGTH_SHORT).show();
                    }
                }
                dbm.close();

                intent.putExtra("keyname",f1);
                startActivity(intent);
            }
        });
    }

    private void speak() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say the amount");

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
        }
        catch (Exception e){
            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case REQUEST_CODE_SPEECH_INPUT:{
                if(resultCode == RESULT_OK && null != data){
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    mTexTv.setText(result.get(0));
                }
                break;
            }
        }
    }
}
