package com.example.safespend;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper
{

    public static final String KEY_ROWID = "_id";
    public static final String KEY_EUROFIFTY = "efifty";
    public static final String KEY_EUROTWENTY = "etwenty";
    public static final String KEY_EUROTEN = "eten";
    public static final String KEY_EUROFIVE = "efive";
    public static final String KEY_EUROTWO = "etwo";
    public static final String KEY_EUROONE = "eone";
    public static final String KEY_CENTFIFTY = "cfifty";
    public static final String KEY_CENTTWENTY = "ctwenty";
    public static final String KEY_CENTTEN = "cten";
    public static final String KEY_CENTFIVE = "cfive";
    public static final String KEY_CENTONE = "cone";


    public static final String DATABASE_NAME = "MoneyApp";
    public static final String DATABASE_TABLE_WALLET = "Wallet";
    public static final int DATABASE_VERSION = 1;

    private static final String DATABASE_CREATE_WALLET =
            "create table " + DATABASE_TABLE_WALLET  +
                    " (" + KEY_ROWID + " integer primary key default 1, " +
                    KEY_EUROFIFTY + " integer, " +
                    KEY_EUROTWENTY + " integer, " +
                    KEY_EUROTEN + " integer, " +
                    KEY_EUROFIVE + " integer, " +
                    KEY_EUROTWO + " integer, " +
                    KEY_EUROONE + " integer, " +
                    KEY_CENTFIFTY + " integer, " +
                    KEY_CENTTWENTY + " integer, " +
                    KEY_CENTTEN + " integer, " +
                    KEY_CENTFIVE + " integer, " +
                    KEY_CENTONE + " integer);";


    public DatabaseHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(DATABASE_CREATE_WALLET);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE_WALLET);

        onCreate(db);
    }
}
