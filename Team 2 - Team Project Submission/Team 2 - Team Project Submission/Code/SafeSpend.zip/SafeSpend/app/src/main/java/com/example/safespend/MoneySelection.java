package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.safespend.R;
import com.example.safespend.model.ItemList;

public class MoneySelection extends AppCompatActivity {
    private ImageView imgItemDetail;
    private TextView TitleDetail;
    private TextView DescriptionDetail;
    private ItemList itemDetail;
    ImageButton imageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setTitle(getClass().getSimpleName());

        initViews();
        initValues();

        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.icon);

        imageButton = (ImageButton) findViewById(R.id.imageButton);
        //final Context context = this;
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                Intent intent = new Intent(MoneySelection.this, MainActivity.class);
                startActivity(intent);

            }

        });

        imageButton = (ImageButton) findViewById(R.id.backButton);
        //final Context context = this;
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                Intent intent = new Intent(MoneySelection.this, MainActivity.class);
                startActivity(intent);

            }

        });

        imageButton = (ImageButton) findViewById(R.id.noCheck);
        //final Context context = this;
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                Intent intent = new Intent(MoneySelection.this, MainActivity.class);
                startActivity(intent);

            }

        });


    }

    private void initViews() {
        imgItemDetail = findViewById(R.id.imgItemDetail);
        TitleDetail = findViewById(R.id.TitleDetail);
        // DescriptionDetail = findViewById(R.id.DescriptionDetail);
    }

    private void initValues(){
        itemDetail = (ItemList) getIntent().getExtras().getSerializable("itemDetail");

        imgItemDetail.setImageResource(itemDetail.getImgResource());
        TitleDetail.setText(itemDetail.getTitulo());
        //DescriptionDetail.setText(itemDetail.getDescription());
    }
}
