package com.example.safespend.model;

import java.io.Serializable;

public class ItemList implements Serializable {
    private String title;
    private String description;
    private int imgResource;

    public ItemList(String title, String description, int imgResource) {
        this.title = title;
        this.description = description;
        this.imgResource = imgResource;
    }

    public String getTitulo() {
        return title;
    }

    public String getDescripcion() {
        return description;
    }

    public int getImgResource() {
        return imgResource;
    }
}
