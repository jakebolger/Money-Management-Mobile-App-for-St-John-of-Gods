package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.media.MediaPlayer;


public class InsertMoney extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_money);

        /*For the sounds: Microphone, Camera and MoneyList*/
        ImageView microphone = (ImageView) this.findViewById(R.id.imageView6);
        ImageView Camera = (ImageView) this.findViewById(R.id.imageView);
        ImageView MoneyList = (ImageView) this.findViewById(R.id.imageView7);
        
        
        /*for the home button to bring to main activity*/
        ImageView homebutton = (ImageView) findViewById(R.id.homeButton);
        homebutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(InsertMoney.this, MainActivity.class);
                startActivity(intent);
            }
        });
        

        /*For the sound: Microphone*/
        final MediaPlayer PlayMic = MediaPlayer.create(this, R.raw.microphone);
        microphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayMic.start();
            }
        });

        /*For the sound: Camera*/
        final MediaPlayer PlayCam = MediaPlayer.create(this, R.raw.camera);
        Camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayCam.start();
            }
        });

        /*For the sound: MoneyList*/
        final MediaPlayer PlayML = MediaPlayer.create(this, R.raw.money_list);
        MoneyList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlayML.start();
            }
        });

        /*Switch Screen from INSERT MONEY to PHOTO*/


        /*Switch Screen from INSERT MONEY to MONEY LIST*/
        ImageView iv10 = (ImageView) findViewById(R.id.imageView10);
        iv10.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent(InsertMoney.this, CoinsActivity.class);
                startActivity(intent);
            }
        });

        /*Switch Screen from INSERT MONEY to TEXT TO SPEECH*/
        ImageView iv9 = (ImageView) findViewById(R.id.imageView9);
        iv9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InsertMoney.this, MicActivity.class);
                startActivity(intent);
            }
        });

        ImageView iv8 = (ImageView) findViewById(R.id.imageView8);
        iv8.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InsertMoney.this, PhotoActivity.class);
                startActivity(intent);
            }


        });

    }

}
