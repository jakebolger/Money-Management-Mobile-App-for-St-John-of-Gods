package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import static com.example.safespend.CoinsActivity.total;

public class NotesActivity extends AppCompatActivity {

    DatabaseManager dbm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        dbm = new DatabaseManager(this);

        TextView tv = (TextView) findViewById(R.id.total);
        tv.setText(total[0] + "€");

        ImageButton homeButton = findViewById(R.id.HomeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(NotesActivity.this, MainActivity.class);
                startActivity(switchFlashlight);
            }
        });


        ImageButton backButton = findViewById(R.id.BackButton);
        /* backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        }); */
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(NotesActivity.this, com.example.safespend.CoinsActivity.class);
                startActivity(switchFlashlight);
            }
        });

        ImageButton tickButton = findViewById(R.id.TickButton);
        tickButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(NotesActivity.this, MainActivity.class);
                startActivity(switchFlashlight);
            }
        });

        ImageButton xButton = findViewById(R.id.XButton);
        xButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.initWallet();
                dbm.close();
                total[0] = 0;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EfiftyButton = findViewById(R.id.Euro50Button);
        EfiftyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEfifty();
                dbm.close();
                total[0] += 50;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EtwentyButton = findViewById(R.id.Euro20Button);
        EtwentyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEtwenty();
                dbm.close();
                total[0] += 20;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EtenButton = findViewById(R.id.Euro10Button);
        EtenButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEten();
                dbm.close();
                total[0] += 10;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EfiveButton = findViewById(R.id.Euro5Button);
        EfiveButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEfive();
                dbm.close();
                total[0] += 5;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });
    }
}
