package com.example.safespend;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import static com.example.safespend.DatabaseHelper.DATABASE_TABLE_WALLET;
import static com.example.safespend.DatabaseHelper.KEY_ROWID;
import static com.example.safespend.DatabaseHelper.KEY_EUROFIFTY;
import static com.example.safespend.DatabaseHelper.KEY_EUROTWENTY;
import static com.example.safespend.DatabaseHelper.KEY_EUROTEN;
import static com.example.safespend.DatabaseHelper.KEY_EUROFIVE;
import static com.example.safespend.DatabaseHelper.KEY_EUROTWO;
import static com.example.safespend.DatabaseHelper.KEY_EUROONE;
import static com.example.safespend.DatabaseHelper.KEY_CENTFIFTY;
import static com.example.safespend.DatabaseHelper.KEY_CENTTWENTY;
import static com.example.safespend.DatabaseHelper.KEY_CENTTEN;
import static com.example.safespend.DatabaseHelper.KEY_CENTFIVE;
import static com.example.safespend.DatabaseHelper.KEY_CENTONE;


public class DatabaseManager
{
    Context context;
    private com.example.safespend.DatabaseHelper myDatabaseHelper;
    private SQLiteDatabase myDatabase;

    public DatabaseManager(Context context)
    {
        this.context = context;
    }

    public DatabaseManager open() throws SQLException {
        myDatabaseHelper = new com.example.safespend.DatabaseHelper(context);
        myDatabase = myDatabaseHelper.getWritableDatabase();
        return this;
    }

    public void close()
    {
        myDatabaseHelper.close();
    }

    public long createWallet()
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_EUROFIFTY, 0);
        initialValues.put(KEY_EUROTWENTY, 0);
        initialValues.put(KEY_EUROTEN, 0);
        initialValues.put(KEY_EUROFIVE, 0);
        initialValues.put(KEY_EUROTWO, 0);
        initialValues.put(KEY_EUROONE, 0);
        initialValues.put(KEY_CENTFIFTY, 0);
        initialValues.put(KEY_CENTTWENTY, 0);
        initialValues.put(KEY_CENTTEN, 0);
        initialValues.put(KEY_CENTFIVE, 0);
        initialValues.put(KEY_CENTONE, 0);
        return myDatabase.insert(DATABASE_TABLE_WALLET, null, initialValues);
    }

    public void initWallet()
    {
        ContentValues args = new ContentValues();
        args.put(KEY_EUROFIFTY, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_EUROTWENTY, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_EUROTEN, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_EUROFIVE, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_EUROTWO, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_EUROONE, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_CENTFIFTY, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_CENTTWENTY, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_CENTTEN, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_CENTFIVE, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
        args.put(KEY_CENTONE, 0);
        myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "= 1", null);
    }

    public boolean deleteWallet()
    {
        return myDatabase.delete(DATABASE_TABLE_WALLET, KEY_ROWID + "!= 1", null) > 0;
    }

    public int getEtwo () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROTWO
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEtwo()
    {
        ContentValues args = new ContentValues();
        int updated = getEtwo() + 1;
        args.put(KEY_EUROTWO, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEtwo()
    {
        ContentValues args = new ContentValues();
        int updated = getEtwo() - 1;
        args.put(KEY_EUROTWO, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getEone () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROONE
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEone()
    {
        ContentValues args = new ContentValues();
        int updated = getEone() + 1;
        args.put(KEY_EUROONE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEone()
    {
        ContentValues args = new ContentValues();
        int updated = getEone() - 1;
        args.put(KEY_EUROONE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getCfifty () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_CENTFIFTY
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increCfifty()
    {
        ContentValues args = new ContentValues();
        int updated = getCfifty() + 1;
        args.put(KEY_CENTFIFTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreCfifty()
    {
        ContentValues args = new ContentValues();
        int updated = getCfifty() - 1;
        args.put(KEY_CENTFIFTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }


    public int getCtwenty () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_CENTTWENTY
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increCtwenty()
    {
        ContentValues args = new ContentValues();
        int updated = getCtwenty() + 1;
        args.put(KEY_CENTTWENTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreCtwenty()
    {
        ContentValues args = new ContentValues();
        int updated = getCtwenty() - 1;
        args.put(KEY_CENTTWENTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }


    public int getCten () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_CENTTEN
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increCten()
    {
        ContentValues args = new ContentValues();
        int updated = getCten() + 1;
        args.put(KEY_CENTTEN, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreCten()
    {
        ContentValues args = new ContentValues();
        int updated = getCten() - 1;
        args.put(KEY_CENTTEN, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getCfive () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_CENTFIVE
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increCfive()
    {
        ContentValues args = new ContentValues();
        int updated = getCfive() + 1;
        args.put(KEY_CENTFIVE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreCfive()
    {
        ContentValues args = new ContentValues();
        int updated = getCfive() - 1;
        args.put(KEY_CENTFIVE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getCone () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_CENTONE
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increCone()
    {
        ContentValues args = new ContentValues();
        int updated = getCone() + 1;
        args.put(KEY_CENTONE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreCone()
    {
        ContentValues args = new ContentValues();
        int updated = getCone() - 1;
        args.put(KEY_CENTONE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }


    public int getEfifty () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROFIFTY
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEfifty()
    {
        ContentValues args = new ContentValues();
        int updated = getEfifty() + 1;
        args.put(KEY_EUROFIFTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEfifty()
    {
        ContentValues args = new ContentValues();
        int updated = getEfifty() - 1;
        args.put(KEY_EUROFIFTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getEtwenty () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROTWENTY
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEtwenty()
    {
        ContentValues args = new ContentValues();
        int updated = getEtwenty() + 1;
        args.put(KEY_EUROTWENTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEtwenty()
    {
        ContentValues args = new ContentValues();
        int updated = getEtwenty() - 1;
        args.put(KEY_EUROTWENTY, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getEten () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROTEN
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEten()
    {
        ContentValues args = new ContentValues();
        int updated = getEten() + 1;
        args.put(KEY_EUROTEN, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEten()
    {
        ContentValues args = new ContentValues();
        int updated = getEten() - 1;
        args.put(KEY_EUROTEN, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public int getEfive () throws SQLException
    {
        Cursor mCursor =
                myDatabase.query(true, DATABASE_TABLE_WALLET, new String[] {
                                KEY_EUROFIVE
                        },
                        KEY_ROWID + " = 1",
                        null,
                        null,
                        null,
                        null,
                        null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        int output = mCursor.getInt(0);
        return output;
    }

    public boolean increEfive()
    {
        ContentValues args = new ContentValues();
        int updated = getEfive() + 1;
        args.put(KEY_EUROFIVE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public boolean decreEfive()
    {
        ContentValues args = new ContentValues();
        int updated = getEfive() - 1;
        args.put(KEY_EUROFIVE, updated);
        return myDatabase.update(DATABASE_TABLE_WALLET, args,
                KEY_ROWID + "=" + 1, null) > 0;
    }

    public Cursor getAll()
    {
        return myDatabase.query(DATABASE_TABLE_WALLET, new String[] {
                        KEY_ROWID,
                        KEY_EUROFIFTY,
                        KEY_EUROTWENTY,
                        KEY_EUROTEN,
                        KEY_EUROFIVE,
                        KEY_EUROTWO,
                        KEY_EUROONE,
                        KEY_CENTFIFTY,
                        KEY_CENTTWENTY,
                        KEY_CENTTEN,
                        KEY_CENTFIVE,
                        KEY_CENTONE},
                null,
                null,
                null,
                null,
                null);
    }

}
