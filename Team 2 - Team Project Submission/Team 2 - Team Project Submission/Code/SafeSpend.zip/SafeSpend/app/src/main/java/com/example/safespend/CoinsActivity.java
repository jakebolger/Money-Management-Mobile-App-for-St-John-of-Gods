package com.example.safespend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class CoinsActivity extends AppCompatActivity {

    DatabaseManager dbm;

    public static final float[] total = {0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coins);

        dbm = new DatabaseManager(this);

        dbm.open();
        dbm.deleteWallet();
        dbm.createWallet();

        float totalValue = (float) (dbm.getEfifty() * 50 + dbm.getEtwenty() * 20 + dbm.getEten() * 10
                + dbm.getEfive() * 5 + dbm.getEtwo() * 2 + dbm.getEone() * 1
                + dbm.getCfifty() * 0.5 + dbm.getCtwenty() * 0.2 + dbm.getCten() * 0.1
                + dbm.getCfive() * 0.05 + dbm.getCone() * 0.01);
        dbm.close();
        total[0] = totalValue;
        TextView tv = (TextView) findViewById(R.id.total);
        tv.setText(total[0] + "€");

        ImageButton backButton = findViewById(R.id.BackButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(CoinsActivity.this, InsertMoney.class);
                startActivity(switchFlashlight);
            }
        });

        ImageButton homeButton = findViewById(R.id.HomeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(CoinsActivity.this, MainActivity.class);
                startActivity(switchFlashlight);
            }
        });


        ImageButton tickButton = findViewById(R.id.TickButton);
        tickButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent switchFlashlight = new Intent(CoinsActivity.this, NotesActivity.class);
                startActivity(switchFlashlight);
            }
        });

        ImageButton xButton = findViewById(R.id.XButton);
        xButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.initWallet();
                dbm.close();
                total[0] = 0;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EtwoButton = findViewById(R.id.Euro2Button);
        EtwoButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEtwo();
                dbm.close();
                total[0] += 2;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton EoneButton = findViewById(R.id.Euro1Button);
        EoneButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increEone();
                dbm.close();
                total[0] += 1;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton CfiftyButton = findViewById(R.id.Cent50Button);
        CfiftyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increCfifty();
                dbm.close();
                total[0] += 0.5;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton CtwentyButton = findViewById(R.id.Cent20Button);
        CtwentyButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increCtwenty();
                dbm.close();
                total[0] += 0.2;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton CtenButton = findViewById(R.id.Cent10Button);
        CtenButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increCten();
                dbm.close();
                total[0] += 0.1;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton CfiveButton = findViewById(R.id.Cent5Button);
        CfiveButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increCfive();
                dbm.close();
                total[0] += 0.05;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });

        ImageButton ConeButton = findViewById(R.id.Cent1Button);
        ConeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dbm.open();
                dbm.increCone();
                dbm.close();
                total[0] += 0.01;
                TextView tv = (TextView) findViewById(R.id.total);
                tv.setText(total[0] + "€");
            }
        });
    }
}
